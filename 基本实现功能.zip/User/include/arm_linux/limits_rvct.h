/*
 * limits_rvct.h
 *
 * Copyright (C) ARM Limited, 2007,2008,2010. All rights reserved.
 *
 * RCS $Revision$
 * Checkin $Date$
 * Revising $Author$
 * $URL$
 */

#define __ARMCLIB_VERSION 6220000

#warning "limits_rvct.h is deprecated, please use limits_armcc.h instead."

#include <limits_armcc.h>

/* end of limits_rvct.h */

