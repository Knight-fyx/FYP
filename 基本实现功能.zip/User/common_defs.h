

#ifndef __COMMON_DEFS_H
#define __COMMON_DEFS_H

#define MAX_CMD_LENGTH 128

#endif



